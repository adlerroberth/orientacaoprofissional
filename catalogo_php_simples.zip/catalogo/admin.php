<?php
$arquivo_json = 'produtos.json';
if (!file_exists($arquivo_json)) {
    file_put_contents($arquivo_json, json_encode([]));
}
if (isset($_POST['enviar'])) {
    $nome = trim($_POST['nome']);
    $preco = trim($_POST['preco']);
    $descricao = trim($_POST['descricao']);
    $imagem = $_FILES['imagem']['name'];
    $tmp = $_FILES['imagem']['tmp_name'];
    $destino = 'upload/' . basename($imagem);
    if (move_uploaded_file($tmp, $destino)) {
        $novo_produto = ['nome' => $nome, 'preco' => $preco, 'descricao' => $descricao, 'imagem' => $destino];
        $produtos = json_decode(file_get_contents($arquivo_json), true);
        $produtos[] = $novo_produto;
        file_put_contents($arquivo_json, json_encode($produtos, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        echo "<p style='color:green;'>✅ Produto cadastrado com sucesso!</p>";
    } else {
        echo "<p style='color:red;'>❌ Falha no upload da imagem.</p>";
    }
}
if (isset($_GET['delete'])) {
    $index = (int)$_GET['delete'];
    $produtos = json_decode(file_get_contents($arquivo_json), true);
    if (isset($produtos[$index])) {
        if (file_exists($produtos[$index]['imagem'])) unlink($produtos[$index]['imagem']);
        unset($produtos[$index]);
        file_put_contents($arquivo_json, json_encode(array_values($produtos), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        echo "<p style='color:red;'>❌ Produto excluído.</p>";
    }
}
$produtos = json_decode(file_get_contents($arquivo_json), true);
?>
<!DOCTYPE html>
<html lang='pt-BR'>
<head>
<meta charset='UTF-8'>
<title>Painel Admin - Catálogo</title>
<style>
body { font-family: Arial; margin: 40px; background: #f4f4f4; }
form { background: white; padding: 20px; border-radius: 10px; width: 320px; margin: auto; box-shadow: 0 2px 5px rgba(0,0,0,0.2); }
input, textarea { width: 100%; margin-bottom: 10px; padding: 8px; border-radius: 5px; border: 1px solid #ccc; }
button { background: #007bff; color: white; border: none; padding: 10px; cursor: pointer; border-radius: 5px; width: 100%; }
h2, h3 { text-align: center; }
.produtos { max-width: 600px; margin: 20px auto; background: white; padding: 15px; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.2); }
.item { display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #ddd; padding: 8px 0; }
.item img { width: 60px; height: 60px; object-fit: cover; border-radius: 5px; }
.item a { color: red; text-decoration: none; font-weight: bold; }
</style>
</head>
<body>
<h2>Admin - Cadastrar Produto</h2>
<form method='POST' enctype='multipart/form-data'>
    <label>Nome:</label>
    <input type='text' name='nome' required>
    <label>Preço:</label>
    <input type='text' name='preco' required>
    <label>Descrição:</label>
    <textarea name='descricao' rows='4'></textarea>
    <label>Imagem:</label>
    <input type='file' name='imagem' accept='image/*' required>
    <button type='submit' name='enviar'>Cadastrar Produto</button>
</form>
<h3>Produtos Cadastrados</h3>
<div class='produtos'>
<?php
if (!empty($produtos)) {
    foreach ($produtos as $i => $p) {
        echo "<div class='item'>";
        echo "<img src='{$p['imagem']}' alt='{$p['nome']}'>";
        echo "<span>{$p['nome']} - R$ {$p['preco']}</span>";
        echo "<a href='?delete=$i' onclick='return confirm("Deseja realmente excluir?")'>Excluir</a>";
        echo "</div>";
    }
} else {
    echo '<p>Nenhum produto cadastrado.</p>';
}
?>
</div>
</body>
</html>

<?php
$arquivo_json = 'produtos.json';
$produtos = file_exists($arquivo_json) ? json_decode(file_get_contents($arquivo_json), true) : [];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Catálogo de Produtos</title>
<style>
body { font-family: Arial; background: #f4f4f4; margin: 0; }
h1 { text-align: center; padding: 20px; }
.catalogo { display: flex; flex-wrap: wrap; justify-content: center; padding: 20px; }
.card { background: white; margin: 10px; padding: 15px; width: 220px; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.2); text-align: center; }
.card img { width: 100%; height: 150px; object-fit: cover; border-radius: 10px; }
.card h3 { margin: 10px 0 5px; }
.card p { font-size: 14px; color: #555; }
.price { color: green; font-weight: bold; }
</style>
</head>
<body>
<h1>Catálogo de Produtos</h1>
<div class="catalogo">
<?php
if (!empty($produtos)) {
    foreach (array_reverse($produtos) as $p) {
        echo "<div class='card'>";
        echo "<img src='{$p['imagem']}' alt='{$p['nome']}'>";
        echo "<h3>{$p['nome']}</h3>";
        echo "<p class='price'>R$ {$p['preco']}</p>";
        echo "<p>{$p['descricao']}</p>";
        echo "</div>";
    }
} else {
    echo "<p>Nenhum produto cadastrado ainda.</p>";
}
?>
</div>
</body>
</html>
